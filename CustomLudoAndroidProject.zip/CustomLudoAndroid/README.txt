CUSTOM 2v2 LUDO - ANDROID STUDIO PROJECT

This is an Android WebView wrapper around the current local Ludo prototype.

HOW TO BUILD AN APK:
1. Install Android Studio on a computer.
2. Open this extracted folder (CustomLudoAndroid) in Android Studio.
3. Allow Android Studio to download the required Gradle and Android SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will create the APK under app/build/outputs/apk/debug/.

Package: com.customludo.game
Minimum Android: 6.0 (API 23)

This project is source code, not a precompiled APK. The prototype is local/offline;
online multiplayer and Play Store publishing are not included.
